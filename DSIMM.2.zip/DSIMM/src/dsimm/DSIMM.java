package dsimm;

import com.mxgraph.swing.mxGraphComponent;
import com.mxgraph.view.mxGraph;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.HashMap;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author Logan
 */
public class DSIMM extends JFrame {
    protected static mxGraph graph = new mxGraph();
    protected static HashMap m = new HashMap();
    private mxGraphComponent graphComponent;
    private JTextField texts;
    private JButton btnAdd;
    private JButton btnDelete;
    private JButton btnConnect;
    private Object cell;
    /**
     * Creates new form DSIMMGUI
     */
    public static HashMap getM()
    {
        return m;
    }
    
    public static mxGraph getGraph()
    {
        return graph;
    }
    
    public DSIMM() {
        super("DSIMM");
        main();
    }
    /**
     * @param args the command line arguments
     */
    private void main() {
        setSize(700, 500);
        setLocationRelativeTo(null);
        
        graphComponent = new mxGraphComponent(graph);
        graphComponent.setPreferredSize(new Dimension(670, 380));
        getContentPane().add(graphComponent);
        
        texts = new JTextField();
        getContentPane().add(texts);
        texts.setPreferredSize(new Dimension(520, 21));
        setLayout(new FlowLayout(FlowLayout.LEFT));
        
        btnAdd = new JButton("Add");
        getContentPane().add(btnAdd);
        btnAdd.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                AddGraph add = new AddGraph(texts.getText());
                texts.setText("");
            }
        });
        
        btnDelete = new JButton("Delete");
        getContentPane().add(btnDelete);
        btnDelete.addActionListener(new ActionListener()
        {
                @Override
                public void actionPerformed(ActionEvent arg0)
                {
                        graph.getModel().remove(cell);
                }   
        });
        
        btnConnect = new JButton("Connect");
        getContentPane().add(btnConnect);
        btnConnect.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                AddRow row = new AddRow();
            }
        });
        
        graphComponent.getGraphControl().addMouseListener(new MouseAdapter()
		{
		
			public void mouseReleased(MouseEvent e)
			{
				cell = graphComponent.getCellAt(e.getX(), e.getY());		
			}
		});
	}
    }
