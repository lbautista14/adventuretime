/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsimm;
/**
 *
 * @author Logan
 */
import java.util.HashMap;
import com.mxgraph.view.mxGraph;

public class AddGraph extends DSIMM
{
    public AddGraph(String nome)
    {
        this.getGraph().getModel().beginUpdate();
        Object parent = this.getGraph().getDefaultParent();
        Object v1 = this.getGraph().insertVertex(parent, null, nome, 330, 30, 100, 50);
        graph.getModel().endUpdate();
    }
}
