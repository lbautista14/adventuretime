/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsimm;

/**
 *
 * @author Logan
 */
public class Principal {
    public Principal()
    {
        DSIMM a = new DSIMM();
        a.setVisible(true);
    }
    
    public static void main(String args[])
    {
        new Principal();
    }
}
