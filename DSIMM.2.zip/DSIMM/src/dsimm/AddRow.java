/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsimm;

import java.util.HashMap;
import javax.swing.JOptionPane;
import com.mxgraph.view.mxGraph;

/**
 *
 * @author Logan
 */
public class AddRow extends DSIMM
{
    public AddRow()
    {
        Object parent = this.getGraph().getDefaultParent();
        Object v1 = this.getM().get(JOptionPane.showInputDialog("Enter the graph 1:"));
        Object v2 = this.getM().get(JOptionPane.showInputDialog("Enter the graph 2:"));
        String nome = JOptionPane.showInputDialog("Enter the name of the line:");
        this.getGraph().insertEdge(parent, null, nome, v1, v2);
    }
}
